using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeliveryEnd : MonoBehaviour
{
//    public Material onMaterial;
//     public Material offMaterial;
//     public GameObject myButton;
    public GameObject Kardus;
//     bool m_State;
//     GameObject m_Area;
//     PyramidArea m_AreaComponent;
//     int m_PyramidIndex;

    // public bool GetState()
    // {
    //     return m_State;
    // }

    void Start()
    {
        // m_Area = gameObject.transform.parent.gameObject;
        // m_AreaComponent = m_Area.GetComponent<PyramidArea>();
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("agent"))
        {
            
            // myButton.GetComponent<Renderer>().material = onMaterial;
            // m_State = true;
            // m_AreaComponent.CreatePyramid(1, m_PyramidIndex);
            // tag = "switchOn";
            Kardus.SetActive(true);
        }
    }
}
