﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class GUI_Demo : MonoBehaviour
{
    public GUISkin guiSkin;
    Rect windowRect = new Rect(0, 0, 400, 200);
    string textToEdit = "Tulis Perintah";
    bool toggleKerja = false;
    bool toggleKendali = false;
    bool toggleCommon = false;
    public Transform target; // Objek yang akan dipindahkan
    public PlayerController playerControl;
    public PyramidAgent MyAgent;
    private int score = 0;
    private string listItems = "";

    void Start()
    {
        windowRect.x = (Screen.width - windowRect.width) / 2;
        windowRect.y = (Screen.height - windowRect.height) / 2;
        toggleKendali = true;
    }

    void OnGUI()
    {
        GUI.skin = guiSkin;
        windowRect = GUI.Window(0, windowRect, DoMyWindow, "Panel");
    }

    public void setBrainList(string add){
        listItems = listItems +" ,"+add;
    }

    public void setScore(int sc){
        score +=sc;
    }

    void DoMyWindow(int windowID)
    {
        bool prevCommon = toggleCommon;
        bool prevKendali = toggleKendali;
        bool prevKerja = toggleKerja;

        GUI.Label(new Rect(200, 40, 150, 30), "Score: " + score.ToString());

        // Toggle untuk "Common"
        toggleCommon = GUI.Toggle(new Rect(20, 10, 100, 30), toggleCommon, "Common");
        if (toggleCommon && !prevCommon)
        {
            toggleKendali = false;
            toggleKerja = false;
            playerControl.SetControlState("Common");
            MyAgent.SetControlState("Common");
        }

        // Toggle untuk "Kendali"
        toggleKendali = GUI.Toggle(new Rect(20, 40, 100, 30), toggleKendali, "Kendali");
        if (toggleKendali && !prevKendali)
        {
            toggleCommon = false;
            toggleKerja = false;
            playerControl.SetControlState("Kendali");
            MyAgent.SetControlState("Kendalli");
        }

        // Toggle untuk "Bekerja"
        toggleKerja = GUI.Toggle(new Rect(20, 70, 100, 30), toggleKerja, "Bekerja");
        if (toggleKerja && !prevKerja)
        {
            toggleCommon = false;
            toggleKendali = false;
            playerControl.SetControlState("Bekerja");
            MyAgent.SetControlState("Bekerja");
        }
        // Tombol "Jalan" untuk mulai eksekusi perintah
        // if (GUI.Button(new Rect(300, 50, 100, 20), "Jalan"))
        // {
        //     Debug.Log("Input: " + textToEdit);
        //     StartMoving();
        // }

        
         GUI.Label(new Rect(200, 50, 150, 30), "Anda menemukan: " + listItems);
        

        // Menjalankan perintah saat tombol ENTER ditekan
        Event e = Event.current;
        if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Return)
        {
            StartMoving();
        }
        GUI.enabled = toggleCommon;

        // TextArea untuk input teks
        textToEdit = GUI.TextArea(new Rect(20, 90, 350, 100), textToEdit, 200);

        // **Aktifkan kembali GUI untuk elemen lain setelah TextArea**
        GUI.enabled = true;

        // Memungkinkan window untuk di-drag
        GUI.DragWindow(new Rect(0, 0, 10000, 10000));
    }

    void StartMoving()
    {
        StopAllCoroutines(); // Hentikan proses sebelumnya
        StartCoroutine(MoveTargetToObjects());
    }

    IEnumerator MoveTargetToObjects()
    {
        // Pisahkan input berdasarkan koma (`,`)
        string[] commands = textToEdit.Split(',');

        bool found = commands.Any(commands => commands.Trim().Contains("ayo kerja"));

        if (!found){
            List<GameObject> actionObjects = new List<GameObject>();
            GameObject[] allObjects = GameObject.FindObjectsOfType<GameObject>();

            // Loop untuk setiap perintah
            foreach (string command in commands)
            {
                string trimmedCommand = command.Trim(); // Hapus spasi berlebih
                string[] words = trimmedCommand.Split(' '); // Pisahkan kata dalam perintah

                if (words.Length < 2)
                {
                    continue;
                }
                
                foreach (string word in words)
                {
                    foreach (GameObject obj in allObjects)
                    {
                        if (obj.name.ToLower() == word.ToLower())
                        {
                            actionObjects.Add(obj);
                            break; // Ambil hanya satu objek pertama yang cocok
                        }
                    }
                }
            }

            if (actionObjects.Count > 0)
            {
                foreach (GameObject obj in actionObjects)
                {
                    // Debug.Log("Berpindah ke objek: " + obj.name);

                    // Pindahkan target ke objek yang ditemukan
                    target.position = new Vector3(obj.transform.position.x, target.position.y, obj.transform.position.z);

                    // Tunggu 5 detik sebelum pindah ke objek berikutnya
                    yield return new WaitForSeconds(5);
                }
            }
            else
            {
                // Debug.LogWarning("Tidak ada objek ditemukan dalam perintah: " + textToEdit);
            }
        }else{
            StartCoroutine(EnableDisableController());
            
        }
    }

    IEnumerator EnableDisableController()
    {
        toggleCommon = false;
        toggleKerja = false;
        playerControl.SetControlState("Kendali");
        MyAgent.SetControlState("Kendalli");
        yield return new WaitForSeconds(0.2f); // Jeda 0.1 detik
        toggleCommon = false;
        toggleKendali = false;
        toggleKerja = true;
        playerControl.SetControlState("Bekerja");
        MyAgent.SetControlState("Bekerja");
    }
}
