using UnityEngine;

public class IsometricCamera : MonoBehaviour
{
    public Transform player;       // Referensi ke objek pemain
    public float distance = 2f;   // Jarak kamera dari pemain
    public float height = 2f;     // Ketinggian kamera di atas pemain
    public float rotationSpeed = 5f; // Kecepatan rotasi kamera
    public Vector3 offset;         // Offset tambahan dari posisi pemain

    private void Start()
    {
        // Mengatur offset kamera pada saat pertama kali dimulai
        offset = new Vector3(0, height, -distance);
    }

    private void Update()
    {
        // Mengikuti posisi pemain, dengan offset isometrik
        Vector3 targetPosition = player.position + offset;

        // Lerp posisi kamera agar lebih halus
        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * rotationSpeed);

        // Mengatur kamera untuk menghadap ke pemain
        transform.LookAt(player.position + new Vector3(0, 1f, 0)); // Sedikit mengarah ke atas pemain agar lebih alami
    }
}
