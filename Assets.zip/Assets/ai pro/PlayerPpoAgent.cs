using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

public class PlayerPpoAgent : Agent
{
    public float moveSpeed = 5f;
    private Rigidbody rb;

    public Transform target; // Target yang harus dicapai agen
    public Transform lingkunganNavigation; // Target yang harus dicapai agen
    private Vector3 startPos; // Posisi awal agen
    private Bounds floorBounds; // Batas lingkungan dari lantai

    public override void Initialize()
    {
        rb = GetComponent<Rigidbody>();
        startPos = transform.position; // Simpan posisi awal

          // Ambil ukuran lantai secara otomatis dari Collider atau Renderer
        if (lingkunganNavigation != null)
        {
            Collider floorCollider = lingkunganNavigation.GetComponent<Collider>();
            if (floorCollider != null)
            {
                floorBounds = floorCollider.bounds;
            }
            else
            {
                MeshRenderer floorRenderer = lingkunganNavigation.GetComponent<MeshRenderer>();
                if (floorRenderer != null)
                {
                    floorBounds = floorRenderer.bounds;
                }
            }
        }
    }

    public override void OnEpisodeBegin()
    {
        // Reset posisi agen ke posisi awal
        transform.position = startPos;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

         // Pastikan lantai terdeteksi sebelum mengacak target
        if (lingkunganNavigation != null)
        {
            // Ambil batas dari ukuran lantai
            float minX = floorBounds.min.x;
            float maxX = floorBounds.max.x;
            float minZ = floorBounds.min.z;
            float maxZ = floorBounds.max.z;

            // Randomisasi posisi target dalam batas lantai
            float targetX = Random.Range(minX, maxX);
            float targetZ = Random.Range(minZ, maxZ);
            target.position = new Vector3(targetX, 1, targetZ);
        }
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        // Mengamati posisi agen
        sensor.AddObservation(transform.position);
        // Mengamati posisi target
        sensor.AddObservation(target.position);
        // Mengamati vektor arah ke target
        sensor.AddObservation(target.position - transform.position);
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        float moveX = actions.ContinuousActions[0];
        float moveZ = actions.ContinuousActions[1];

        Debug.Log($"MoveX: {moveX}, MoveZ: {moveZ}");
        
        Vector3 move = new Vector3(moveX, 0, moveZ) * moveSpeed * Time.deltaTime;
        rb.MovePosition(transform.position + move);

        // Hitung jarak ke target
        float distanceToTarget = Vector3.Distance(transform.position, target.position);

        // Beri reward jika agen mendekati target
        AddReward(1.0f / distanceToTarget);

        // Jika agen mencapai target, beri reward besar dan mulai ulang episode
        if (distanceToTarget < 1.0f)
        {
            AddReward(10.0f); // Reward besar
            EndEpisode(); // Restart episode
        }

        // Jika agen keluar dari batas area, beri penalti dan mulai ulang episode
        if (transform.position.y < 0)
        {
            AddReward(-5.0f); // Penalti
            EndEpisode(); // Restart episode
        }
    }
}
