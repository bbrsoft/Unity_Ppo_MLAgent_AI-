using UnityEngine;
using UnityEngine.AI;
using System.Collections;


public class PlayerNavigation : MonoBehaviour
{
    public NavMeshAgent agent;
    public Transform target; // Tujuan yang bisa ditentukan
    public GameObject[] posisiLetakBarang;
    public int step = 0;
    public Animator animator;
    public float stopDistance = 2f; // Jarak untuk berhenti dan idle
    public CharacterController controller;
    public PlayerController playerControl;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
    }

    public void SetControlStep(int state)
    {
        step = state;
    }

    public int GetStep(){
        return step;
    }

    void Update()
    {
        if (target != null)
        {
            agent.SetDestination(target.position);
            if(playerControl.GetControlState() == "Common"){
                HandleAnimation();
            }
        }
       if (target == null || posisiLetakBarang.Length == 0)
            return;

        if(playerControl.GetControlState() == "Bekerja"){
            // Jika target telah mencapai posisinya dan pose = 0, ubah ke 1 dan pilih target baru
            if (step == 0 && Vector3.Distance(transform.position, target.position) < 1f)
            {
                Transform child = transform.Find("kardus");
                if (child != null)
                {
                    child.SetParent(transform);
                }
                StartCoroutine(EnableDisableController());
            }
            // Jika target telah mencapai posisinya dan pose = 1, ubah kembali ke 0
            else if (step == 1 && Vector3.Distance(transform.position, target.position) < 1f)
            {
                step = 2;
            }
        }
    }

    IEnumerator EnableDisableController()
    {
        controller.enabled = true;
        yield return new WaitForSeconds(0.3f); // Jeda 0.1 detik
        controller.enabled = false;
        step = 1;
        PilihPosisiBaru();
    }

    void PilihPosisiBaru()
    {
        int indexTerdekat = 0;
        float jarakTerdekat = Mathf.Infinity;
        Vector3 posisiSaatIni = target.position; // Posisi saat ini

        // Cari posisi yang paling dekat
        for (int i = 0; i < posisiLetakBarang.Length; i++)
        {
            float jarak = Vector3.Distance(posisiSaatIni, posisiLetakBarang[i].transform.position);
            if (jarak < jarakTerdekat)
            {
                jarakTerdekat = jarak;
                indexTerdekat = i;
            }
        }

        // Atur posisi ke lokasi terdekat
        target.position = posisiLetakBarang[indexTerdekat].transform.position;

    }

    void HandleAnimation()
    {
        float distance = Vector3.Distance(transform.position, target.position);

        if (distance > stopDistance)
        {
             animator.Play("Run");
        }
        else
        {
             animator.Play("Stand");
        }
    }

    public void SetNewTarget(Transform newTarget)
    {
        target = newTarget;
    }
}
