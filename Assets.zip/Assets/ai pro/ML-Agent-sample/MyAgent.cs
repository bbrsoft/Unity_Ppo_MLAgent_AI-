using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using UnityEngine;
using UnityEngine.AI;

public class MyAgent : Agent
{
    public Transform target;
    public Transform Navtarget;
    public float speed = 3f;
    private float baseSPeed = 3f;
    public float smoothSpeed = 0.125f; // Kecepatan smoothing pergerakan
    private string isEnabledComponent = "comman";
    public PlayerNavigation PlayerNavigation;
    public GUI_Demo GUI_Demo;
    public NavMeshAgent NavAgent;
    public PlayerController PlayerController;

    void Start()
    {
        if (NavAgent == null)
        {
            NavAgent = GetComponent<NavMeshAgent>(); // Ambil komponen jika belum di-set
        }

        InvokeRepeating("DecreaseStep", 1f, 0.1f); 
    }

    private void DecreaseStep()
    {
        if (baseSPeed < 20f)
        {
            SetSpeed(0.1f);
        }
        else
        {
            CancelInvoke("DecreaseStep"); // Berhenti jika MaxStep sudah 0
        }
    }

    public void SetSpeed(float newSpeed)
    {
        if (NavAgent != null)
        {
            NavAgent.speed = newSpeed + baseSPeed;
        }
    }

    void Update(){
        
    }

    public void SetControlState(string state)
    {
        isEnabledComponent = state;
    }

    // Reset posisi AI dan target setiap episode mulai
    public override void OnEpisodeBegin()
    {
        PlayerController.setPicup(true);
        if (PlayerNavigation.GetStep() == 2)
        {
            // SetReward();
            GUI_Demo.setScore(10);
         
        }

        if (isEnabledComponent == "Bekerja") {
            // transform.position = GetRandomPosition();
            target.position = GetRandomPosition();
            Navtarget.position = target.position;
            PlayerNavigation.SetControlStep(0);
        }

        // if(MaxStep >0 && MaxStep<200 ){
        //     MaxStep=200;
        // }else if(MaxStep >200 && MaxStep<300 ){
        //     SetSpeed(15);
        // }else if(MaxStep >300 && MaxStep<400){
        //     SetSpeed(7f);
        // }else if(MaxStep >400 ){
        //     SetSpeed(3f);
        // }
    }

    // Memberikan informasi ke AI tentang posisi dirinya dan target
    public override void CollectObservations(VectorSensor sensor)
    {
        // sensor.AddObservation(transform.position);
        sensor.AddObservation(target.position);
    }

    // Memberikan aksi berdasarkan keputusan AI
    public override void OnActionReceived(ActionBuffers actions)
    {
        // Arahkan AI ke target
        Vector3 directionToTarget = (target.position - transform.position).normalized;

        // Tentukan target posisi baru (move per frame)
        Vector3 targetPosition = transform.position + directionToTarget * speed * Time.deltaTime;       

        

        // Lerp untuk pergerakan yang lebih halus
        // transform.position = Vector3.Lerp(transform.position, targetPosition, smoothSpeed);

        // Jika AI mencapai target, beri reward dan pindahkan target
        // if (Vector3.Distance(transform.position, target.position) < 1.5f)
        // {
            
        //     // target.position = GetRandomPosition();
        // }
    }

    // Fungsi untuk mendapatkan posisi acak dalam batas tertentu
    private Vector3 GetRandomPosition()
    {
        return new Vector3(Random.Range(-10f, 10f), 0f, Random.Range(-10f, 10f));
    }
    private void SetReward(){
        GUI_Demo.setScore(10);
    }
}
