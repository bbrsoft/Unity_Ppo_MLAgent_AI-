using System;

public class CommandParser
{
    public struct SPOK
    {
        public string Subject;   // Subjek (misal: player)
        public string Predicate; // Predikat (misal: makan)
        public string Object;    // Objek (misal: nasi)
        public string Keterangan; // Keterangan (misal: di meja)
    }

    // Fungsi untuk mem-parsing perintah yang dimasukkan
    public static SPOK ParseCommand(string input)
    {
        string[] words = input.ToLower().Split(' '); // Memisahkan kata-kata berdasarkan spasi
        SPOK result = new SPOK();

        // Contoh sederhana: "player makan nasi di meja"
        if (words.Length >= 2)
        {
            result.Subject = words[0];    // Ambil kata pertama sebagai subject
            result.Predicate = words[1];  // Kata kedua sebagai predikat

            if (words.Length >= 3)
                result.Object = words[2];  // Kata ketiga sebagai objek
            
            if (words.Length >= 4)
                result.Keterangan = words[3]; // Kata keempat sebagai keterangan (opsional)
        }

        return result;
    }
}
