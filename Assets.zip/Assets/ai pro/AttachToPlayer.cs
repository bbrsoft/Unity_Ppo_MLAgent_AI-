using UnityEngine;

public class AttachToPlayer : MonoBehaviour
{
    private Transform playerTransform;
    public float maxDistance = 1.5f; // Jarak maksimum dari player

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // Jadikan karakter sebagai parent objek ini
            transform.SetParent(other.transform);
            playerTransform = other.transform;

            // Set posisi awal relatif terhadap player
            transform.localPosition = new Vector3(0, 1, 0.4f);
        }
    }

    private void Update()
    {
        // Pastikan objek masih menjadi child dari player
        if (transform.parent != null && transform.parent.CompareTag("Player"))
        {
            // Hitung jarak antara objek dan player
            float distance = Vector3.Distance(transform.position, playerTransform.position);

            // Jika terlalu jauh, kembalikan ke posisi relatif yang diinginkan
            if (distance > maxDistance)
            {
                transform.localPosition = new Vector3(0, 1, 0.4f);
            }
        }
    }
}
