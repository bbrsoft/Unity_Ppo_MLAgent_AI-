using UnityEngine;
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float gravity = -9.81f;
    public float rotationSpeed = 100f; // Kecepatan rotasi
    public CharacterController controller;
    public PyramidAgent MyAgent;
    // private PlayerNavigation playernav;
    private string isEnabledComponent = "comman";
    // private NavMeshAgent navMeshAgent;
    public Animator animator;
    public bool pickup = true;
     

    private Vector3 velocity;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        // playernav = GetComponent<PlayerNavigation>();
        // navMeshAgent = GetComponent<NavMeshAgent>();
        MyAgent.enabled = false;
    }

     // Method untuk mengontrol CharacterController dari script lain
    public void SetControlState(string state)
    {
        isEnabledComponent = state;
    }

    public string GetControlState()
    {
        return isEnabledComponent;
    }

    public void setPicup(bool pick){
        pickup =  pick;
    }

     void ToggleControl()
    {
       
        // Aktif/nonaktifkan CharacterController dan NavMeshAgent
        if (isEnabledComponent == "Common") {
            controller.enabled = false;
            // playernav.enabled = true;
            // navMeshAgent.enabled = true;
            MyAgent.enabled = false;
          
          
        }else  if (isEnabledComponent == "Kendali") {
            // playernav.enabled = false;
            controller.enabled = true;
            // navMeshAgent.enabled = false;
            MyAgent.enabled = false;
          
            
        }else  if (isEnabledComponent == "Bekerja") {
            // playernav.enabled = true;
            controller.enabled = false;
            // navMeshAgent.enabled = true;
            MyAgent.enabled = true;
        }


        // Debug.Log("Player Control: " + isEnabledComponent);
    }

    void Update()
    {
        ToggleControl();
        // Ambil input dari keyboard
        float moveZ = Input.GetAxis("Vertical");   // W & S (Maju/Mundur)
        float rotateZ = Input.GetAxis("Horizontal"); // A & D (Rotasi Z)

        if (isEnabledComponent == "Kendali" ) {
            if(moveZ != 0){
                animator.Play("Run");
            }else{
                animator.Play("Stand");
            }
        }else if (isEnabledComponent == "Bekerja") {
            // if(playernav.GetStep() == 0){
                animator.Play("Run");
            // }else if(playernav.GetStep() == 1){
            //     animator.Play("Pick");
            // }else{
            //     animator.Play("Stand");
            // }
        }
        // Gerakkan karakter hanya pada sumbu Z (maju/mundur)
        Vector3 move = transform.forward * moveZ;
        controller.Move(move * moveSpeed * Time.deltaTime);

        // Putar karakter di sumbu Z menggunakan A dan D
        transform.Rotate(0, rotateZ * rotationSpeed * Time.deltaTime, 0);

        // Tambahkan gravitasi agar karakter tetap di tanah
        if (controller.isGrounded && velocity.y < 0)
        {
            velocity.y = -2f; // Reset gravitasi saat di tanah
        }

        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
}
