using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIController : MonoBehaviour
{
    public GameObject player; // Objek karakter utama (player)

    void Start()
    {
        // Contoh pemakaian untuk menjalankan perintah
        // ExecuteCommand("player makan nasi");
        // ExecuteCommand("player lari ke taman");
    }

    // Fungsi untuk mengeksekusi perintah
    public void ExecuteCommand(string command)
    {
        CommandParser.SPOK parsed = CommandParser.ParseCommand(command); // Parsing perintah

        // Menangani aksi berdasarkan predikat yang di-parsing
        if (parsed.Predicate == "makan")
        {
            Debug.Log($"{parsed.Subject} sedang makan {parsed.Object}.");
            // Tambahkan animasi atau logika makan di sini
        }
        else if (parsed.Predicate == "lari")
        {
            Debug.Log($"{parsed.Subject} mulai berlari ke {parsed.Keterangan}.");
            // Tambahkan logika pergerakan
            MovePlayerTo(parsed.Keterangan);
        }
        else
        {
            Debug.Log("Perintah tidak dikenali!");
        }
    }

    // Fungsi untuk menggerakkan player ke lokasi tertentu
    void MovePlayerTo(string location)
    {
        // Contoh pergerakan: Bisa menggunakan NavMesh atau manipulasi transform untuk bergerak
        Debug.Log($"Bergerak ke {location}...");
        // Misalnya, bisa menggunakan transform untuk bergerak
        // player.transform.position = new Vector3(...);  // Ganti posisi sesuai dengan lokasi
    }
}
